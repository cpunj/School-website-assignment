Purpose of the website-
I have tried to keep the website simple and easy for users on both mobile version and desktop
version. I have put the design pretty simple for pages as brighter colors or images
irritates the user's eyes while browsing. Careful consideration was given towards
the options present in the website to make it easier for the users to perform the 
functions they want. The enrolment page is minimalized to just two bars which when
clicked display the units available in a particular year. Like this way the site was
kept very simplistic. Site has been fully connected with the database management system
and uses MYSQL to return all the outputs. 

Functions for the website -
- User will be easily able to navigate from page to another using the navigation bar.
- User will be able to sign up by filling a simple registration form and data will be
stored in the students table in mysql from where all the data can be extracted and validated.
User has to choose their role from lecturer,DC,UC,student.
- Only DC will be able to edit unit details .
-Only DC and UC will be able to edit academic staff details.
Current DC account=Email-chandan@gmail.com
Password-desmond@17

Tried to implement reset password but it didn't work
Current UC account= Email- gordon@gmail.com
Password- desmond@17
- The timetable will be able to display the timetable for specific user using session.
- Student will be able to enrol, allocate and timetable.
Current student account 
Email= barbara@gmail.com
Password= desmond@17

Testing can be easily done using these.

Update details has only one problem. password keeps getting encrypted againa and again 
even if other details are changed. Rest is working fine.

